# SAD-SlideBar
Aquí realitzarem l'exercici de la SlideBar

# Fet
D'aquest exercici només hem substituit el codi ascii del simbol de la barra i hem realitzat les funcions per saber la mida del terminal
